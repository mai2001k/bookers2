# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '9febf9437b275b9ae20d0ffedab69a3895c253efe0067d3f660eb4a869292359855b8bc7a1f0a38779f2fd3b6107d681d3812387c9edd6df679601cdec38a2ff'